import ProjectsView from './projects/index';
export default ProjectsView;